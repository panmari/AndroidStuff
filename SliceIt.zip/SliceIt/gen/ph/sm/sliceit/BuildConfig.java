/** Automatically generated file. DO NOT MODIFY */
package ph.sm.sliceit;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}