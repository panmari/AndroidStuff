// BtChatQuit.java
// Base class for BtChatServer/BtChatClient

public abstract class BtChatQuit 
{
  protected abstract void quit();
}
